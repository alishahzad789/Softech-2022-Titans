package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ManageEvents extends AppCompatActivity {

    Button btn6,btn5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_events);
        btn6=findViewById(R.id.button6);
        btn5=findViewById(R.id.button5);
        Toast.makeText(getApplicationContext(), "HERE!!", Toast.LENGTH_SHORT).show();
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "HERE!!1", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(ManageEvents.this, Events.class);
                startActivity(i);
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "HERE!!2", Toast.LENGTH_SHORT).show();

                Intent switchActivityIntent = new Intent(getApplicationContext(), Participants.class);
                startActivity(switchActivityIntent);
            }
        });

    }
}