package com.example.softecregisterationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class register_as_sponsor extends AppCompatActivity {
    ProgressDialog progressDialog;
    FirebaseAuth mAuth;
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_as_sponsor);

        EditText et_email=findViewById(R.id.et_email2);
        EditText et_company=findViewById(R.id.et_company_name2);
        EditText et_phone=findViewById(R.id.et_phone);
        EditText et_password=findViewById(R.id.et_password2);



        FloatingActionButton btn_signin=findViewById(R.id.btnsubmit);

        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email= et_email.getText().toString().trim();
                String password= et_password.getText().toString().trim();
                String company= et_company.getText().toString().trim();
                String phone= et_phone.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    et_email.setError("This Field cannot be empty");
                }
                if(TextUtils.isEmpty(company)){
                    et_password.setError("This Field cannot be empty");

                }

                if(TextUtils.isEmpty(phone)){
                    et_phone.setError("This Field cannot be empty");

                }
                if(TextUtils.isEmpty(password)){
                    et_password.setError("This Field cannot be empty");

                }
                else if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(password)){
                    register(company,email,password,phone);
                }
            }
        });
    }






    void register(String company,String email,String password,String phone){
        ProgressDialog progressDialog = new ProgressDialog(register_as_sponsor.this);
        progressDialog.setMessage("Registering please wait"); // Setting Message
        progressDialog.setTitle("Registration"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        progressDialog.setCancelable(false);
        FirebaseAuth auth = FirebaseAuth.getInstance();

        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                //Log.d("TAG","SUCCESSFUL");
                if (task.isSuccessful()){
                    //Log.d("TAG","SUCCESSFUL inside check");

                    FirebaseUser user=auth.getCurrentUser();
                    user.sendEmailVerification();

                    reference= FirebaseDatabase.getInstance().getReference("Users").
                            child(user.getUid());
                    if(user!=null){
                        HashMap<String,Object> hashmap=new HashMap<>();
                        hashmap.put("UID",user.getUid());
                        hashmap.put("company",company);
                        hashmap.put("email",email);
                        hashmap.put("password",password);
                        hashmap.put("user_type","sponsor");
                        hashmap.put("phone",phone);



                        reference.setValue(hashmap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(register_as_sponsor.this, "Registered", Toast.LENGTH_SHORT).show();
                                    progressDialog.dismiss();

                                    //Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                                    //startActivity(intent);
                                    FirebaseAuth.getInstance().signOut();
                                    finish();

                                }
                            }
                        });
                    }
                }

                else{
                    progressDialog.dismiss();
                    AlertDialog alertDialog = new AlertDialog.Builder(register_as_sponsor.this).create();
                    alertDialog.setTitle("Alert");
                    alertDialog.setMessage(" "+task.getException().getMessage());
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    //Log.d("TAG","error "+task);
                }
            }
        });

    }

}