package com.example.softecregisterationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class sponsor_category_3 extends AppCompatActivity {

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsor_category3);


        data_from_firebase();

        Button btn_submit=findViewById(R.id.btn_submit_spsonsor);
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout layout=findViewById(R.id.layout_2);
                final int childCount = layout.getChildCount();

                ArrayList<HashMap<String,String>> list_of_stall=new ArrayList<>();
                for (int i = 0; i < childCount; i++) {
                    View v = layout.getChildAt(i);
                    CheckBox checkBox= (CheckBox) v;
                    list_of_stall.add((HashMap<String,String>)checkBox.getTag());
                    Log.d("tag","data: "+checkBox.getText());
                    // …
                }

                Intent intent = new Intent(getApplicationContext(),payment_sponsor_1.class);
                intent.putExtra("perk_info",getIntent().getSerializableExtra("perk_info"));
                intent.putExtra("stall_info",list_of_stall);
                intent.putExtra("category_type",getIntent().getStringExtra("category_type"));
                startActivity(intent);



            }
        });





    }
    void data_from_firebase(){
        ProgressDialog progressDialog = new ProgressDialog(sponsor_category_3.this);
        progressDialog.setMessage("Please wait"); // Setting Message
        progressDialog.setTitle("Appointment"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        progressDialog.setCancelable(false);

        LinearLayout layout=findViewById(R.id.layout_2);
        LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        String perk_type =getIntent().getStringExtra("category_type");
        databaseReference= FirebaseDatabase.getInstance().getReference("stalls").
                child(perk_type);
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.hasChildren()){
                    for (DataSnapshot snapshot1: snapshot.getChildren()){
                        HashMap<String,String> map= (HashMap<String,String>)snapshot1.getValue();


                        CheckBox checkBox = new CheckBox(getApplicationContext());



                        if(Boolean.parseBoolean(map.get("book_status").toString())){
                            checkBox.setClickable(false);
                        }
                        checkBox.setText(""+map.get("name"));
                        checkBox.setId(View.generateViewId());
                        checkBox.setTextSize(22);
                        checkBox.setTag(map);
                        checkBox.setLayoutParams(lparams);

                        layout.addView(checkBox);
                    }

                    progressDialog.dismiss();
                }
                else{
                    progressDialog.dismiss();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}