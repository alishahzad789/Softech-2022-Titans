package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class sponsor_homepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsor_homepage);
        Button btn_cat=findViewById(R.id.btn_category);
        Button btn_stall=findViewById(R.id.btn_stall_list);




        btn_cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent =new Intent(getApplicationContext(),sponsor_category_1.class);
                startActivity(intent);
            }
        });

    }
}