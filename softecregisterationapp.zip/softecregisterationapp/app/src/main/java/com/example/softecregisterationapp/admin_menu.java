package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class admin_menu extends AppCompatActivity {

    TextInputLayout txt1;
    String studentID;
    Button btn3,btn4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);
        btn3=findViewById(R.id.button3);
        btn4=findViewById(R.id.button4);

        FirebaseDatabase FD;
        DatabaseReference DR;
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switchActivityIntent = new Intent(getApplicationContext(), ManageEvents.class);
                startActivity(switchActivityIntent);
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switchActivityIntent = new Intent(getApplicationContext(), ManageStalls.class);
                startActivity(switchActivityIntent);
            }
        });
    }
}