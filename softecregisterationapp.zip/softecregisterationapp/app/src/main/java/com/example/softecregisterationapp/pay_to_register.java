package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.os.Handler;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;


public class pay_to_register extends AppCompatActivity {
    private ProgressDialog Progress;
    HashMap<String,String> data;
    DatabaseReference reference;
    String email;
    private Button btn;
    long time=5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_to_register);


        String EventName;
        String myname;
        String myemail;
        String myphone;
        String cnic;
        String myuni;
        String email2mate;
        String email3mate;


        Bundle extras = getIntent().getExtras();


        if(extras == null) {
            //in case of error no intent data go back
            EventName= null;
            EventName= null;
            myname=null;
            myemail=null;
            myphone=null;
            cnic=null;
            myuni=null;
            email2mate=null;
            email3mate=null;
            Intent i=new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);

        } else {
            data= new HashMap<>();

            EventName= extras.getString("event_name_extra");
            myname=extras.getString("my_name_extra");
            myemail=extras.getString("my_email_extra");
            myphone=extras.getString("my_phone_extra");
            cnic=extras.getString("my_cnic_extra");
            myuni=extras.getString("my_myuni_extra");
            email2mate=extras.getString("my_n2email_extra");
            email3mate=extras.getString("my_n3email_extra");
            email=extras.getString("my_email_extra");

            data.put("event_name_extra",EventName);
            data.put("my_name_extra",myname);
            data.put("my_email_extra",myemail);
            data.put("my_phone_extra",myphone);
            data.put("my_cnic_extra",cnic);
            data.put("my_myuni_extra",myuni);
            data.put("my_n2email_extra",email2mate);
            data.put("my_n3email_extra",email3mate);



        }


        Progress = new ProgressDialog(this);
        Progress.setMessage("Verifying...");


        btn = findViewById(R.id.pay);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Progress.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Progress.dismiss();
                        Toast.makeText(getApplicationContext(),"Payment Successful",Toast.LENGTH_SHORT).show();


                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("participants")
                                .child(data.get("my_email_extra").replace(".",")"));
                        myRef.setValue(data);

                        Intent i=new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(i);
                    }

                }, 2000);

            }

        });
    }
}