package com.example.softecregisterationapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class dataadapter  extends RecyclerView.Adapter<dataadapter.MyViewHolder> {

    Context m_context;
    List<HashMap<String,String>>mydata;

    public dataadapter(Context ct,List<HashMap<String,String>>m_li){
        m_context=ct;
        mydata=m_li;
        Log.d("TAG3", "HERE: " + mydata.get(0).toString());
        Log.d("TAG3", "HERE: " + mydata.get(1).toString());
        Log.d("TAG3", "HERE: " + mydata.get(2).toString());
        Log.d("TAG3", "HERE: " + mydata.get(3).toString());
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(m_context);
        View view=inflater.inflate(R.layout.row_layout,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
       HashMap<String,String>Map=mydata.get(position);
       holder.eventname.setText(Map.get("name"));
       String eventName=Map.get("name");
       holder.priceview.setText(Map.get("price"));
       holder.card.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i=new Intent(m_context,participant_reg_form.class);
               String event_name_extra = eventName;
               i.putExtra("EVENT_NAME_EXTRA",event_name_extra);
               m_context.startActivity(i);
           }
       });
    }

    @Override
    public int getItemCount() {
        return mydata.size();
    }

    public class MyViewHolder extends  RecyclerView.ViewHolder{


        CardView card;
        TextView eventname;
        TextView priceview;
        Context context;
        public MyViewHolder(@NonNull View itemview){
            super(itemview);
            card=itemview.findViewById(R.id.cardview);
            eventname=itemview.findViewById(R.id.EventNameView);
            priceview=itemview.findViewById(R.id.EventFeeView);
            context=m_context;

        }

    }
}
