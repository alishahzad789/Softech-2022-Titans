package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Participants extends AppCompatActivity {

    Button btnAdd,btnrem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participants);
        btnAdd=findViewById(R.id.add);
        btnrem=findViewById(R.id.btremove);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Successfully added a new Participant...",Toast.LENGTH_SHORT).show();
                finish();

            }
        });

        btnrem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Successfully removed a Participant...",Toast.LENGTH_SHORT).show();
                finish();

            }
        });
    }
}