package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class noStalls extends AppCompatActivity {

    Button btnrem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_stalls);
        btnrem=findViewById(R.id.rem2);
        btnrem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Successfully freed a stall...",Toast.LENGTH_SHORT).show();
                finish();

            }
        });

    }
}