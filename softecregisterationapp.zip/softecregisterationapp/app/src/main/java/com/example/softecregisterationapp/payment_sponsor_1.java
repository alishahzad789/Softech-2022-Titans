package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;

public class payment_sponsor_1 extends AppCompatActivity {

    private ProgressDialog Progress;
    FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
    private Button btn;
    DatabaseReference reference;
    long time=5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_sponsor1);
        Progress = new ProgressDialog(this);
        Progress.setMessage("Verifying...");
        btn = findViewById(R.id.pay);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Progress.show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Progress.dismiss();
                        Toast.makeText(getApplicationContext(),"Payment Successful",Toast.LENGTH_SHORT).show();
                        Intent intent=getIntent();

                        ArrayList<HashMap<String,String>> stall_data=(ArrayList<HashMap<String,String>>)intent.getSerializableExtra("stall_info");
                        HashMap<String,String> perk_data=(HashMap<String,String>) intent.getSerializableExtra("perk_info");



                        for (HashMap<String,String> data: stall_data) {
                            reference= FirebaseDatabase.getInstance().getReference("stalls").
                                    child(getIntent().getStringExtra("category_type")) .
                                    child(data.get("name")).child("book_status");
                            reference.setValue("true");


                            //Log.d("tag", "data: " +data.get("name"));
                        }



                        for (HashMap<String,String> stall: stall_data){
                            reference=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid())
                                    .child("perk&stall").child("perk").child(getIntent().getStringExtra("category_type")+"1")
                                    .child(stall.get("name"));

                            reference.setValue(stall);
                        }




                        reference=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid())
                                .child("perk&stall").child("perk").child(getIntent().getStringExtra("category_type"));
                        reference.setValue(perk_data);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                        Log.d("tag","data: "+getIntent().getStringExtra("category_type"));


                        if(getIntent().getStringExtra("category_type").matches("gold")){
                            reference=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid())
                                    .child("gold_book");
                            reference.setValue("true");
                        }
                        if(getIntent().getStringExtra("category_type").matches("diamond")){
                            reference=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid())
                                    .child("diamond_book");
                            reference.setValue("true");
                        }
                        if(getIntent().getStringExtra("category_type").matches("platimun")){
                            reference=FirebaseDatabase.getInstance().getReference("Users").child(user.getUid())
                                    .child("platimun_book");
                            reference.setValue("true");
                        }
                        Intent intent1=new Intent(getApplicationContext(), sponsor_homepage.class);
                        startActivity(intent1);











                    }

                }, 2000);

            }

        });















    }
}