package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class register_as_participant extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_as_participant);

        RecyclerView RV=findViewById(R.id.RecylerView);
        RV.setHasFixedSize(true);
        RV.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<HashMap<String,String>>l1=new ArrayList<>();




     /*   DataNode d1=new DataNode("App Dev","042","m.alishahzad789@gmail.com","777","100");
        DataNode d2=new DataNode("Web Dev","041","m.alishahzad786@gmail.com","666","100");
        DataNode d3=new DataNode("Shit Dev","042","m.alishahzad785@gmail.com","123","100");

        l1.add(d1);
        l1.add(d2);
        l1.add(d3);
              */

// Read from the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("event");

        ProgressDialog progressDialog = new ProgressDialog(register_as_participant.this);
        progressDialog.setMessage("Please wait"); // Setting Message
        progressDialog.setTitle("Loading Events"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        progressDialog.setCancelable(false);

        myRef.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int a= (int) dataSnapshot.getChildrenCount();
                Log.d("TAG1", "Count is: " + a);

                for(DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                    l1.add((HashMap<String,String>) dataSnapshot1.getValue());
                    Log.d("TAG1", "Value is: " + dataSnapshot1.getValue());
                }

                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue().toString();
                Log.d("TAG2", "Value is: " + value);
                dataadapter da=new dataadapter(register_as_participant.this,l1);
                RV.setAdapter(da);

                progressDialog.dismiss();
               // Test(l1);
                // Log.d("TAG", "Value is: " + value);
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("TAG", "Failed to read value.", error.toException());
            }
        });


    }
    public void Test( ArrayList<HashMap<String,String>>lt1){
         int a=10;
    }
}