package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class admin_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        Button btnsub=findViewById(R.id.btn_submit2);
        EditText et_email3=findViewById(R.id.et_email3);
        EditText et_password3=findViewById(R.id.et_password3);

        btnsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String password = et_password3.getText().toString();
                String email = et_email3.getText().toString();


                if (password.length() == 0) {
                    et_password3.setError("Please enter password name");
                }
                if (email.length() == 0) {
                    et_email3.setError("Please enter email");

                } else if (password.length() > 0 && email.length() > 1)
                {
                  if(email.equals("admin") && password.equals("123")){
                      Toast.makeText(getApplicationContext(), "LOGIN SUCCESFUL...", Toast.LENGTH_SHORT).show();
                      Intent i= new Intent(getApplicationContext(),admin_menu.class);
                      startActivity(i);
                  }
                }

            }
        });
    }
}