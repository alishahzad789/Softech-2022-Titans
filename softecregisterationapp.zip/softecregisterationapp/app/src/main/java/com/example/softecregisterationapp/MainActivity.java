package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button ToRegisterSponsor;
        ToRegisterSponsor=findViewById(R.id.SponsorRegisterbtn);
        Button ToRegisterParticipant=findViewById(R.id.ParticipanRegistertbtn);
        Button ToAdminLogin=findViewById(R.id.adminbtn);

        ToRegisterParticipant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), register_as_participant.class);
                startActivity(i);
            }
        });
        ToRegisterSponsor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), login_signin_sponsor.class);
                startActivity(i);
            }
        });
        ToAdminLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), admin_login.class);
                startActivity(i);
            }
        });

    }
}