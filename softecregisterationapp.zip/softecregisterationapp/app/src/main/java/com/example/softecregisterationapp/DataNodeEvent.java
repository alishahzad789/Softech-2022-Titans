package com.example.softecregisterationapp;

public class DataNodeEvent {
    private String EventName;
    private String Price;
    private String UniqueId;

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }


    public DataNodeEvent(String eventName,String price) {
        EventName = eventName;
        Price=price;

    }

    public String getEventName() {
        return EventName;
    }

    public void setEventName(String eventName) {
        EventName = eventName;
    }


    public void setUniqueId(String uniqueId) {
        UniqueId = uniqueId;
    }

    public String getUniqueId() {
        return UniqueId;
    }
}
