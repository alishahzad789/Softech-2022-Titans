package com.example.softecregisterationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class sponsor_category_2 extends AppCompatActivity {

    array_adapter_for_perk_list arrayadapter;
    ArrayList<HashMap<String,String>> perks_data = new ArrayList<>();

    DatabaseReference counselor_db;
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsor_category2);

        data_from_firebase();

        arrayadapter= new array_adapter_for_perk_list
                (this,R.layout.layout_perks,perks_data);

        ListView lv = findViewById(R.id.list_view_perks);
        lv.setAdapter(arrayadapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                HashMap<String, String> obj =perks_data.get(position);
                Intent data= new Intent(getApplicationContext(),sponsor_category_3.class);
                data.putExtra("perk_info",obj);
                data.putExtra("category_type",getIntent().getStringExtra("category_type"));
                startActivity(data);



            }
        });

    }

    void data_from_firebase(){
        ProgressDialog progressDialog = new ProgressDialog(sponsor_category_2.this);
        progressDialog.setMessage("Please wait"); // Setting Message
        progressDialog.setTitle("Loading Data"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        progressDialog.setCancelable(false);
        String perk_type =getIntent().getStringExtra("category_type");
        counselor_db= FirebaseDatabase.getInstance().getReference("perks").
                child(perk_type);
        counselor_db.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.hasChildren()){
                    for (DataSnapshot snapshot1: snapshot.getChildren()){
                        perks_data.add((HashMap<String,String>)snapshot1.getValue());

                    }
                    arrayadapter.notifyDataSetChanged();
                    progressDialog.dismiss();
                }
                else{
                    progressDialog.dismiss();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });







    }
}