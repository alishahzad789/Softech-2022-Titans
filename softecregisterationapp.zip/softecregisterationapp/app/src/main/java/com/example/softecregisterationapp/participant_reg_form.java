package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class participant_reg_form extends AppCompatActivity {
    String EventName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participant_reg_form);

        Bundle extras = getIntent().getExtras();



        if(extras == null) {
            //in case of error no intent data go back
            EventName= null;
            Intent i=new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);

        } else {
            EventName= extras.getString("EVENT_NAME_EXTRA");
        }


        Button Registerbtn=findViewById(R.id.RegisterBtn);

        TextView mynameview=findViewById(R.id.MyNameView);
        TextView myemailview=findViewById(R.id.MyEmailView);
        TextView myphonenoview=findViewById(R.id.MyPhoneNoView);
        TextView mycnicview=findViewById(R.id.MyCnicView);
        TextView myuniview=findViewById(R.id.MyUniView);

        TextView secondmatenameview=findViewById(R.id.SecondMateName);
        TextView secondmateemailview=findViewById(R.id.SecondMateEmail);
        TextView secondmateuniview=findViewById(R.id.SecondMateUni);

        TextView thirdmatenameview=findViewById(R.id.ThirdMateName);
        TextView thirddmateemailview=findViewById(R.id.ThirdMateEmail);
        TextView thirddmateuniview=findViewById(R.id.ThirdMateUni);


        Registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean mtwo=false;
                boolean mthree=false;

                String SecondMateEmail;
                String ThirdMateEmail;
                if(secondmateemailview.getText().length()>0){
                    mtwo=true;
                    SecondMateEmail=secondmateemailview.getText().toString();

                }
                if(secondmateemailview.getText().length()>0){
                    mthree=true;
                    ThirdMateEmail=thirddmateemailview.getText().toString();
                }

                if(mynameview.getText().length()<=0 || myemailview.getText().length()<=0
                || myphonenoview.getText().length()<=0 || mycnicview.getText().length()<=0
                || myuniview.getText().length()<=0){
                    Toast.makeText(getApplicationContext(), "Main member not found", Toast.LENGTH_SHORT).show();
                }
                else{
                    String myname=mynameview.getText().toString();
                    String myemail=myemailview.getText().toString();
                    String myphone= myphonenoview.getText().toString();
                    String cnic= mycnicview.getText().toString();
                    String myuni= myuniview.getText().toString();


                    String secondemail=null;
                    String thirdemail=null;


                    if(mtwo){
                        secondemail=secondmateemailview.getText().toString();
                    }
                    if(mthree){
                        thirdemail=thirddmateemailview.getText().toString();
                    }
                    ProceedToPayment(myemail,myname,myphone,cnic,myuni,secondemail,thirdemail);
                }
            }
        });


    }
    public void ProceedToPayment(String myemail,String myname,String myphone,String cnic,String myuni,
                                 String n2email,String n3email){

        Intent i = new Intent(getApplicationContext(), pay_to_register.class);
        i.putExtra("event_name_extra",EventName);
        i.putExtra("my_email_extra",myemail);
        i.putExtra("my_name_extra",myname);
        i.putExtra("my_phone_extra",myphone);
        i.putExtra("my_cnic_extra",cnic);
        i.putExtra("my_myuni_extra",myuni);
        i.putExtra("my_n2email_extra",n2email);
        i.putExtra("my_n3email_extra",n3email);
        startActivity(i);
    }
}