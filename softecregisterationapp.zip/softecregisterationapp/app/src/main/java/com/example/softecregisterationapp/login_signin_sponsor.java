package com.example.softecregisterationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;

public class login_signin_sponsor extends AppCompatActivity {
    FirebaseAuth mAuth;
    DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_signin_sponsor);


        EditText et_password = findViewById(R.id.et_password);
        EditText et_email = findViewById(R.id.et_email);


        Button btn_sign_up = findViewById(R.id.btn_signup);
        btn_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), register_as_sponsor.class);
                startActivity(intent);
            }
        });

        Button btn_submit = findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String password = et_password.getText().toString();
                String email = et_email.getText().toString();


                if (password.length() == 0) {
                    et_password.setError("Please enter password name");
                }
                if (email.length() == 0) {
                    et_email.setError("Please enter email");
                } else if (password.length() > 0 && email.length() > 1) {
                    LoginUser(email, password);


                }


            }
        });

    }//oncreate

    void LoginUser(String email, String password) {
        ProgressDialog progressDialog = new ProgressDialog(login_signin_sponsor.this);
        progressDialog.setMessage("logging in "); // Setting Message
        progressDialog.setTitle("Account"); // Setting Title
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
        progressDialog.show(); // Display Progress Dialog
        progressDialog.setCancelable(false);
        mAuth = FirebaseAuth.getInstance();
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    if (user.isEmailVerified()) {


                        Intent intent = new Intent(getApplicationContext(), sponsor_homepage.class);
                        startActivity(intent);


                    } else {
                        progressDialog.dismiss();
                        AlertDialog alertDialog = new AlertDialog.Builder(login_signin_sponsor.this).create();
                        alertDialog.setTitle("Alert");
                        alertDialog.setMessage("Please verify email");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                    }
                } else {
                    progressDialog.dismiss();
                    AlertDialog alertDialog = new AlertDialog.Builder(login_signin_sponsor.this).create();
                    alertDialog.setTitle("Alert");
                    alertDialog.setMessage(" " + task.getException().getMessage());
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }

            }
        });

    }
}