package com.example.softecregisterationapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class array_adapter_for_perk_list extends ArrayAdapter {
    ArrayList<HashMap<String,String>> perk_data=new ArrayList<>();
    private Context mycontext;
    private  int resid;
    private array_adapter_for_perk_list arrayadapter;



    public array_adapter_for_perk_list(@NonNull Context context, int resource, ArrayList<HashMap<String,String>> perk_data1) {
        super(context, resource, perk_data1);

        perk_data=perk_data1;
        mycontext=context;
        resid=resource;
        arrayadapter=this;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater=(LayoutInflater) mycontext.getSystemService(sponsor_category_2.LAYOUT_INFLATER_SERVICE);
        View view =inflater.inflate(resid,null);

        TextView perk=view.findViewById(R.id.et_perk);
        TextView description=view.findViewById(R.id.et_description);

        HashMap<String,String> map= perk_data.get(position);
        perk.setText(""+map.get("title"));
        description.setText(""+map.get("description"));


        return view;
    }

}
