package com.example.softecregisterationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class sponsor_category_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsor_category1);
        Button btn_gold=findViewById(R.id.btn_gold);
        Button btn_platimun=findViewById(R.id.btn_platimun);
        Button btn_diamond=findViewById(R.id.btn_diamond);

        btn_gold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(),sponsor_category_2.class);
                intent.putExtra("category_type","gold");
                startActivity(intent);
            }
        });

        btn_platimun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),sponsor_category_2.class);
                intent.putExtra("category_type","platimun");
                startActivity(intent);
            }
        });

        btn_diamond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),sponsor_category_2.class);
                intent.putExtra("category_type","diamond");
                startActivity(intent);
            }
        });
    }
}